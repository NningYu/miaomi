const Koa = require('koa');
const koaStatic = require('koa-static');
const Router = require('koa-router');//路由
const fs = require('fs');
//--------------------------------------------------------------------
    const app=new Koa(); 
//--------------------------------------------------------------------
//托管静态文件
app.use(koaStatic('xiaoxiao'));
// app.use(KoaBody({
//     multipart:true
// }
// ));//解析数据
//--------------------------------------------------------------------
//路由实例 定义 每一个路由
const router = new Router();
//--------------------------------------------------------------------
router   ///login 不是真实的文件夹
    .get('/xiaomi',ctx=>{ 
        ctx.type='text/html';
        ctx.body =fs.readFileSync('./xiaoxiao/xiaomi.html'); //读取字符串 html字符串
    }) //登入
    .get('/gouwucheyemian',ctx=>{ 
        ctx.type='text/html';
        ctx.body =fs.readFileSync('./xiaoxiao/gouwucheyemian.html'); //读取字符串 html字符串
    }) //登入
    .get('/xiaoai',ctx=>{ 
        ctx.type='text/html';
        ctx.body =fs.readFileSync('./xiaoxiao/xiaoai.html'); //读取字符串 html字符串
    }) //登入 
//--------------------------------------------------------------------
    app
        .use(router.routes())
        .use(router.allowedMethods());//访问方式会做一个校验 如果不是上面访问方式会访问时 会提示一个消息输出是不好使的
//--------------------------------------------------------------------
        app.listen(8080, 'localhost', () => {
            console.log('Server Started.');
          });
    

