var t_44 = document.getElementsByClassName("t_44")[0];
t_44.onmousemove=function(){
    t_44.style.left="0px";
    t_44.style.transition = "0.2s";
}
t_44.onmouseout=function(){
    t_44.style.left="-50px";
    t_44.style.transition = "0.2s";
}

var u4=document.getElementById('u4');
var y_1=document.getElementsByClassName('y_1')[0];
var u5=document.getElementsByClassName('u5')[0];
y_1.onmousemove = function () {   
   u4.style.display="block";
}
y_1.onmouseout = function () {   
    u4.style.display="none";
    u5.style.height="0px";
    u5.style.transition = "0.02s"; 
 }
 u4.onmousemove=function(){
    u4.style.background="#ff6700";
   u4.style.color="#fff";
 }
 u4.onmouseout = function () {   
    u4.style.background="#fff";
    u4.style.color="#ff6700";
 }
 u4.onclick=function(){
   u5.style.height="30px";
   u5.style.transition = "0.03s"; 
 }
 //------------------------------------------------------------------

var u55=document.getElementsByClassName('u55')[0];
var y_11=document.getElementsByClassName('y_11')[0];
var uu4=document.getElementById('uu4');
y_11.onmousemove = function () {   
   uu4.style.display="block";
}
y_11.onmouseout = function () {   
    uu4.style.display="none";
    u55.style.height="0px";
    u55.style.transition = "0.03s"; 
 }
 uu4.onmousemove=function(){
    uu4.style.background="#ff6700";
   uu4.style.color="#fff";
 }
 uu4.onmouseout = function () {   
    uu4.style.background="#fff";
    uu4.style.color="#ff6700";
 }
 uu4.onclick=function(){
   u55.style.height="30px";
   u55.style.transition = "0.03s"; 
 }
//------------------------------------------------------------------

var u555=document.getElementsByClassName('u555')[0];
var y_111=document.getElementsByClassName('y_111')[0];
var uuu4=document.getElementById('uuu4');
y_111.onmousemove = function () {   
   uuu4.style.display="block";
}
y_111.onmouseout = function () {   
    uuu4.style.display="none";
    u555.style.height="0px";
    u555.style.transition = "0.03s"; 
 }
 uuu4.onmousemove=function(){
    uuu4.style.background="#ff6700";
   uuu4.style.color="#fff";
 }
 uuu4.onmouseout = function () {   
    uuu4.style.background="#fff";
    uuu4.style.color="#ff6700";
 }
 uuu4.onclick=function(){
   u555.style.height="30px";
   u555.style.transition = "0.03s"; 
 }
 //------------------------------------------------------------------
var u5555=document.getElementsByClassName('u5555')[0];
var y_1111=document.getElementsByClassName('y_1111')[0];
var uuuu4=document.getElementById('uuuu4');
y_1111.onmousemove = function () {   
   uuuu4.style.display="block";
}
y_1111.onmouseout = function () {   
    uuuu4.style.display="none";
    u5555.style.height="0px";
    u5555.style.transition = "0.1s"; 
 }
 uuuu4.onmousemove=function(){
    uuuu4.style.background="#ff6700";
   uuuu4.style.color="#fff";
 }
 uuuu4.onmouseout = function(){   
    uuuu4.style.background="#fff";
    uuuu4.style.color="#ff6700";
 }
 uuuu4.onclick=function(){
   u5555.style.height="30px";
   u5555.style.transition = "0.1s"; 
 }
 //------------------------------------------------------------------
var y_3=document.getElementsByClassName('y_3')[0];
var u55555=document.getElementsByClassName('u55555')[0];
var uuuuu4=document.getElementById('uuuuu4');
y_3.onmousemove = function () {   
   uuuuu4.style.display="block";
}
y_3.onmouseout = function () {   
    uuuuu4.style.display="none";
    u55555.style.height="0px";
    u55555.style.transition = "0.1s"; 
 }
 uuuuu4.onmousemove=function(){
    uuuuu4.style.background="#ff6700";
   uuuuu4.style.color="#fff";
 }
 uuuuu4.onmouseout = function () {   
    uuuuu4.style.background="#fff";
    uuuuu4.style.color="#ff6700";
 }
 uuuuu4.onclick=function(){
   u55555.style.height="30px";
   u55555.style.transition = "0.1s"; 
 }


var t11=document.getElementsByClassName('t11')[0];
var t12=document.getElementsByClassName('t12')[0];
var t13=document.getElementsByClassName('t13')[0];
// console.log(t11)
t11.onmousemove = function () {   
    t12.style.color="#fff"; 
    t13.style.color="#fff"; 
    t11.style. background= "#ff6700"; 
    t11.style.transition = "0.5s";
}
t11.onmouseout= function () {   
    t12.style.color="#ff6700"; 
    t13.style.color="#ff6700";  
    t11.style. background= "#fff"; 
    t11.style.transition = "0.5s"; 
}  