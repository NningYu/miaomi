var s =document.getElementById("s");
var t = document.getElementById("t");
var zz = document.getElementById("zz");
var cod=document.getElementsByClassName("cod");
s.onmouseover=function(){
    t.style.color="red";
    zz.style.color="red";
    cod[0].style.display="block";  
}
cod[0].onmouseover=function(){
    cod[0].style.display="block";
}
cod[0].onmouseout=function(){
    cod[0].style.display="none";
}
s.onmouseout=function(){
    t.style.color="#9a9a9a";
    zz.style.color="#9a9a9a";
    cod[0].style.display="none";
}
//---------------------------------------
var ss=document.getElementById("ss");
var tt = document.getElementById("tt");
var zzz = document.getElementById("zzz");
ss.onmouseover=function(){
    tt.style.color="red";
    zzz.style.color="red";
}
ss.onmouseout=function(){
    tt.style.color="#9a9a9a";
    zzz.style.color="#9a9a9a";
}
//---------------------------------------
var sss=document.getElementById("sss");
var ttt = document.getElementById("ttt");
var zzzz = document.getElementById("zzzz");
sss.onmouseover=function(){
    ttt.style.color="red";
    zzzz.style.color="red";
}
sss.onmouseout=function(){
    ttt.style.color="#9a9a9a";
    zzzz.style.color="#9a9a9a";
}
//---------------------------------------
var ssss=document.getElementById("ssss");
var tttt = document.getElementById("tttt");
var zzzzz = document.getElementById("zzzzz");
ssss.onmouseover=function(){
    tttt.style.color="red";
    zzzzz.style.color="red";
}
ssss.onmouseout=function(){
    tttt.style.color="#9a9a9a";
    zzzzz.style.color="#9a9a9a";
}
//---------------------------------------
var sssss=document.getElementById("sssss");
var ttttt = document.getElementById("ttttt");
var zzzzzz = document.getElementById("zzzzzz");
sssss.onmouseover=function(){
    ttttt.style.color="red";
    zzzzzz.style.color="red";
}
sssss.onmouseout=function(){
    ttttt.style.color="#9a9a9a";
    zzzzzz.style.color="#9a9a9a";
}
//---------------------------------------
